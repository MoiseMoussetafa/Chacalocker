#ifndef MAINWINDOW_H
#define MAINWINDOW_H


class mainwindow
{
public:
    mainwindow();
};

#endif // MAINWINDOW_H
